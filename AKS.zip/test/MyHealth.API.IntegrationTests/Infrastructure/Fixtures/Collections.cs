namespace MyHealth.API.Infrastructure.Fixtures
{
    public static class Collections
    {
        public const string Database = "Database";
    }
}