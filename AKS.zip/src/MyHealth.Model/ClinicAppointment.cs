﻿
namespace MyHealth.Model
{
    public class ClinicAppointment : Appointment
    {
        public int RoomNumber { get; set; }

    }
}
