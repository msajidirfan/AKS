﻿
namespace MyHealth.Model
{
    public enum Specialities
    {
        Neurosurgeon = 1,
        Orthopedist,
        Cardiologist,
        Ophthalmologist
    }
}
