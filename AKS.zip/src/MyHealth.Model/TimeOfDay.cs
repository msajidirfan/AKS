﻿
namespace MyHealth.Model
{
    public enum TimeOfDay
    {
        Unknown = 0,
        Breakfast = 1,
        Lunch = 2,
        Dinner = 3
    }
}
