﻿class DailyReportController {
    constructor() {
        /* empty */
    }
}

export default DailyReportController;